#ifndef IS_PRIME_H
#define IS_PRIME_H

bool isPrime(int n);

#endif
